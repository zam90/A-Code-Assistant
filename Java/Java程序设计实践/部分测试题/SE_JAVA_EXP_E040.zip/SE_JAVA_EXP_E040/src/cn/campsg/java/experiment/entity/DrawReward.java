package cn.campsg.java.experiment.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DrawReward {
	private Map<Integer,Awards> rwdPool=null;
	public DrawReward(){
		this.rwdPool=new HashMap<Integer,Awards>();
		rwdPool.put(8,new Awards("�صȽ�",1));
		rwdPool.put(1, new Awards("һ�Ƚ�",4));
		rwdPool.put(2,new Awards("���Ƚ�",6));
		rwdPool.put(0,new Awards("���Ƚ�",100));
		
	}
	public void draward (int rdKey){
		Awards aw =this.rwdPool.get(rdKey);
		if(aw==null){
			return;
		}
		if(aw.getCount()<1){
			System.out.println(aw.getName() +"���ý����ѳ��ꡣ");
			}
		aw.setCount(aw.getCount()-1);
		System.out.println("�齱�����"+aw.getName());
		
	}
	public void showSurplus(){
		Iterator<Awards> itor;
		itor = rwdPool.values().iterator();
		for(int i=0;i<rwdPool.size();i++){
			Awards aw = itor.next();
			System.out.println(aw.getName()+";ʣ�½���������"+aw.getCount());
		}
	}
}
