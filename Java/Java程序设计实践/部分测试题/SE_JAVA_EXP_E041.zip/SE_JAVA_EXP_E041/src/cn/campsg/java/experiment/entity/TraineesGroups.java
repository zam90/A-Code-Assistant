package cn.campsg.java.experiment.entity;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TraineesGroups {
	private List<Trainee> trnList;
	private Map<String,List<Trainee>> groups;
	public void initTrainees(List<Trainee> trnList){
		this.trnList=trnList;
	}
	public Map<String,List<Trainee>> groupTrainees(){
		if(trnList.size()==0||trnList==null){
			return null;
		}
		else{
			groups = new HashMap<String, List<Trainee>>();
			groups.put("male", new ArrayList<Trainee>());
			groups.put("female", new ArrayList<Trainee>());
			for(int i=0;i<trnList.size();i++){
				if(trnList.get(i).getSex()=="male"){
					groups.get("male").add(trnList.get(i));
				}
				else{
					groups.get("female").add(trnList.get(i));
				}
			}
			Collections.sort(groups.get("male"));
			Collections.sort(groups.get("female"));
			return groups;
		}
	}
	

}
