package cn.campsg.java.experiment;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import cn.campsg.java.experiment.entity.Trainee;
import cn.campsg.java.experiment.entity.TraineesGroups;

public class MainClass {
	public static void main(String[] args){
		TraineesGroups tg = new TraineesGroups();
		List<Trainee> list1=new ArrayList<>();
		for(int i=0;i<10;i++){
	    	Trainee t=new Trainee();
			t.setName("ѧ��-"+(int)(Math.random()*10));
			t.setHeight((float)(150+Math.random()*50));
			int sexnum=(int)(Math.random()*2);
			if(sexnum==1){
				t.setSex("male");
			}
			else{
				t.setSex("female");
			}
			list1.add(t);
		}
		tg.initTrainees(list1);
		Map<String, List<Trainee>> group = tg.groupTrainees();
		for(int j=0;j<group.get("male").size();j++){
			System.out.println("����:"+group.get("male").get(j).getName()+"����:"+group.get("male").get(j).getHeight()+"�Ա�:"+group.get("male").get(j).getSex());
		}
		System.out.println("===============================");
		for(int k=0;k<group.get("female").size();k++){
			System.out.println("����:"+group.get("female").get(k).getName()+"����:"+group.get("female").get(k).getHeight()+"�Ա�:"+group.get("female").get(k).getSex());
		}
		
	}

}
