package cn.campsg.java.experiment;

import java.util.ArrayList;

public class QueueCaller {
	private ArrayList<String>queue=null;
	 public QueueCaller(){
		 this.queue=new ArrayList<String>();
	 }
	 public int size() {
		 return queue.size();
	 }
	 public void fetchNumber(String patient) {
		 queue.add(patient);
		 System.out.println(patient+"ǰ�滹��"+(size()-1)+"λ�ڵȺ���");
	 }
	 public void showPatients() {
		 if(queue==null){
			 return;
		 }
		 System.out.println( queue+"������");
		 
	  }
	 public void callNumber() {
		 
		 System.out.println("�뻼�ߣ�"+queue.remove(0)+"�����Ҿ���");
	  }
}
