
 
import java.io.FileInputStream;
import java.io.IOException;
 
public class Fileoutput {
    public String readFile(String fileLuJing) throws IOException{
    	StringBuffer s=new StringBuffer();
        byte[] b1=new byte[2048];
        int count=0;
        int i=0;
        FileInputStream f01=new FileInputStream(fileLuJing);
        while(count!=-1){
            b1[i]=(byte)count;
            i++;
            count=f01.read();
        }
        String s1=new String(b1,0,i);
        f01.close();
        return s1;
    }
    public static void main(String[] args){
        Fileoutput f1=new Fileoutput();
        try {
            System.out.println(f1.readFile("d:\\workspace\\CORE_C09_001\\myjava.txt"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
     
 
}
