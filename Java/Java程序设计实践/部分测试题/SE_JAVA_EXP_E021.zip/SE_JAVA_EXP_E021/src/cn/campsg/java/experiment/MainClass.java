/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.campsg.java.experiment;

/**
 *
 * @author Zam90
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Student student = new Student();
        student.setName("黄世仁");
        student.setAge(24);
        student.setSex(true);
        student.setScore(59.0f);
        System.out.println("姓名："+student.getName()+
        "\n年龄："+student.getAge()+"\n性别："+student.getSex()+"\n分数："+student.getScore());
    }
    
}