package cn.campsg.java.experiment;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Zam90
 */
public class Student {
    private String name;
    private int age;
    private boolean sex;
    private float score;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if(age<18){
            this.age = 18;
        }
        else{
            this.age = age;
        } 
    }

    public String getSex() {
        if(sex == true){
            return "男";
        }
        else{
            return "女";
        }
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public float getScore() {
        return score;
    }

    public void setScore(float score) {
        this.score = score;
    }

    public Student() {
    }

    public Student(String name, int age, boolean sex, int score) {
        this.name = "";
        this.age = 0;
        this.sex = true;
        this.score = 0.0f;
    }
    
}
