import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class SchoolManager {
	private List<HashMap<String,Student>>list=new ArrayList<>();
	public void saveClass(HashMap<String,Student>map){
		list.add(map);
	}
	public String getAllStudentByClass(int index){
		String s="�༶"+index+"��ѧ����\n";
		HashMap<String,Student>map=list.get(index);
		Iterator<String>it=map.keySet().iterator();
		while(it.hasNext()){
			String no=it.next();
			s+="ѧ�ţ�"+no+","+map.get(no)+"\n";
		}
		return s;
	}
	public static void main(String[] args){
		SchoolManager sm=new SchoolManager();
		
		HashMap<String,Student>class1=new HashMap<>();
		class1.put("115599", new Student("Roger",21,true));
		class1.put("335577", new Student("July",20,false));
		sm.saveClass(class1);
		
		HashMap<String,Student>class2=new HashMap<>();
		class2.put("123456", new Student("����",22,true));
		class2.put("987654", new Student("����",21,true));
		sm.saveClass(class2);
		
		System.out.println(sm.getAllStudentByClass(1));
	}
}
