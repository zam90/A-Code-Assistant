/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.campsg.practical;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Zam90
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        URL url1;
        url1 = getClass().getResource("/res/layout/main_layout.fxml");
        AnchorPane root = FXMLLoader.load(url1);
        Scene scene = new Scene(root);
        primaryStage.setTitle("消灭泡泡糖-Popstar3");
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();
        //powered by Jingyu Zhang
    }

    public static void main(String[] args) {
        launch(args);
        
    }
    
}
