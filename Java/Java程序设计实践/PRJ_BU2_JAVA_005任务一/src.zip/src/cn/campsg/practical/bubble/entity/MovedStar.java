package cn.campsg.practical.bubble.entity;

public class MovedStar extends Star {
    private Position p = new Position();

    public Position getP() {
        return p;
    }

    public void setP(Position p) {
        this.p = p;
    }

    public MovedStar(Position position, StarType type, Position p) {
        super(position, type);
        this.p = p;
    }
    public static void main(String[] args) {
        Position p1 = new Position(0,0);
        Position p2 = new Position(1,1);
        StarType c = StarType.RED;
        MovedStar ms = new MovedStar(p1,c,p2);
        System.out.println("������ԭλ��:("+p1.getColumn()+","+p1.getRow()+")");
        System.out.println("�������ƶ���Ŀ��λ��λ��:("+p2.getColumn()+","+p2.getRow()+")");
        System.out.println("��������ɫΪ:"+c);
        //powered by Jingyu Zhang
    }
}
