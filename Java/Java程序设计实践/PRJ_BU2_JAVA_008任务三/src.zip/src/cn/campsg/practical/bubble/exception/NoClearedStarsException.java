package cn.campsg.practical.bubble.exception;

public class NoClearedStarsException extends Exception{

	public NoClearedStarsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoClearedStarsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoClearedStarsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
